
// rendering
var divergence = 0.2;
var fieldOfView = 40;
var motionFrames = 5;

// geometry
var cubeCount = 30;
var crossCount = 80;
var circleCount = 40;
var glassCount = 40;
var circleSegment = 16;
var pointCount = 1000;
var lineSegment = 100;
